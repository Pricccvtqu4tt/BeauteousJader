export default {
	state: {
		a: 1
	}
}
